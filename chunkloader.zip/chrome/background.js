// background.js
// This script is currently empty but necessary for the background service worker.
